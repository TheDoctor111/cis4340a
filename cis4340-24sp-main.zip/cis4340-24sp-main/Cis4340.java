/******************************************************************************
 *  Compilation:  javac Cis4340.java
 *  Execution:    java Cis4340
 *
 *  Prints 
 *    "Hello, World - from the class of cis4340 - Spring 2024 - UCF (your name here_)".
 *  By tradition, this is everyone's first program.
 *
 * Revision History:
 *   % java Cis4340
 *  Hello, World - from the class of cis4340 - Spring 2024 - UCF (your name here)
 *  %
 *
 ******************************************************************************/

public class Cis4340 {

    public static void main(String[] args) {
        // Prints "Hello, World" to the terminal window.
        System.out.println("Hello, World - from the class of cis4340 - Spring 2024 - UCF (your name here)");
    }

}
